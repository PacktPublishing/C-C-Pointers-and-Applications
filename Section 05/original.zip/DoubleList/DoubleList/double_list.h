#pragma once
#include <cstddef>
#include <initializer_list>
#include <cassert>

template<typename T>
class DoubleList {
	struct Node {
		T m_Data;
		Node *m_pNext{};
		Node *m_pPrev{};
		Node(const T &data) :m_Data{ data } {

		}
	};
public:
	class Position {
		Node *m_pPosition;
		Position(Node *p) :m_pPosition{ p } {

		}
		friend class DoubleList<T>;
	};
	using size_type = size_t;
	using value_type = T;
	using pointer = T * ;
	using reference = T & ;
	using const_pointer = const T*;
	using const_reference = const T&;
	DoubleList() = default;
	DoubleList(size_type count, const_reference value) {
		assert(count != 0);
		for (int i = 0; i < count; ++i) {
			AddBack(value);
		}
		m_Size = count;
	}
	DoubleList(std::initializer_list<T> values) {
		auto itr = values.begin();
		while (itr != values.end()) {
			Add(*itr++);
		}
		m_Size = values.size();
	}
	DoubleList(const DoubleList<T> &other) {
		if (other.Empty())
			return;
		Copy(other);

	}
	DoubleList(DoubleList<T> &&other) {
		if (other.Empty())
			return;
		m_Size = other.m_Size;
		m_pHead = other.m_pHead;
		m_pTail = other.m_pTail;
		other.m_pHead = other.m_pTail = nullptr;
		other.m_Size = 0;
	}
	DoubleList & operator=(const DoubleList<T> &other) {
		if (this != &other) {
			Clear();
			Copy(other);
		}
		return *this;
	}
	DoubleList &operator=(DoubleList<T> &&other) {
		if (this != &other) {
			Clear();
			m_Size = other.m_Size;
			m_pHead = other.m_pHead;
			m_pTail = other.m_pTail;
			other.m_pHead = other.m_pTail = nullptr;
			other.m_Size = 0;
		}
		return *this;
	}
	~DoubleList() {
		Clear();
	}
	bool Empty()const {
		return m_Size == 0;
	}
	const_reference Front()const{
		assert(!Empty());
		return m_pHead->m_Data;
	}
	const_reference Back()const {
		assert(!Empty());
		return m_pTail->m_Data;
	}
	void Clear() {
		while (!Empty()) {
			RemoveBack();
		}
	}
	void AddFront(const_reference elem) {
		if (Empty()) {
			m_pHead = m_pTail = new Node{ elem };
		}
		else {
			m_pHead->m_pPrev = new Node{ elem };
			m_pHead->m_pPrev->m_pNext = m_pHead;
			m_pHead = m_pHead->m_pPrev;
		}
		++m_Size;
	}
	void AddBack(const_reference elem) {
		if (Empty()) {
			m_pHead = m_pTail = new Node{ elem };
		}
		else {
			m_pTail->m_pNext = new Node{ elem };
			m_pTail->m_pNext->m_pPrev = m_pTail;
			m_pTail = m_pTail->m_pNext;
		}
		++m_Size;
	}
	void RemoveFront() {
		assert(!Empty());
		Node *delNode = m_pHead;
		m_pHead = m_pHead->m_pNext;
		if(m_pHead!=nullptr)
			m_pHead->m_pPrev = nullptr;
		delete delNode;
		if (--m_Size == 0) {
			m_pTail = nullptr;
		}
	}
	void RemoveBack() {
		assert(!Empty());
		Node *delNode = m_pTail;
		m_pTail = m_pTail->m_pPrev;
		if(m_pTail != nullptr)
			m_pTail->m_pNext = nullptr;
		delete delNode;
		if (--m_Size == 0) {
			m_pHead = nullptr;
		}
	}
	void Insert(Position p, const_reference elem) {
		assert(!Empty());
		assert(p.m_pPosition != nullptr);
		if (p.m_pPosition->m_pPrev == nullptr) {
			AddFront(elem);
			return;
		}
		if (p.m_pPosition->m_pNext == nullptr) {
			AddBack(elem);
			return;
		}
		auto new_node = new Node{ elem };
		new_node->m_pPrev = p.m_pPosition->m_pPrev;
		new_node->m_pPrev->m_pNext = new_node;
		new_node->m_pNext = p.m_pPosition;
		p.m_pPosition->m_pPrev = new_node;
		++m_Size;
	}
	void Erase(Position p) {
		assert(!Empty());
		assert(p.m_pPosition != nullptr);
		if (p.m_pPosition->m_pPrev == nullptr) {
			RemoveFront();
			return;
		}
		if (p.m_pPosition->m_pNext == nullptr) {
			RemoveBack();
			return;
		}
		auto del_Node = p.m_pPosition;
		del_Node->m_pPrev->m_pNext = del_Node->m_pNext;
		del_Node->m_pNext->m_pPrev = del_Node->m_pPrev;
		delete del_Node;
		--m_Size;
			
	}
	size_type GetSize()const {
		return m_Size; 
	}
	Position GetFirst()const {
		assert(!Empty());
		return Position{ m_pHead };
	}
	Position GetNext(Position p) {
		p.m_pPosition = p.m_pPosition->m_pNext;
		return p;
	}
	Position GetPrevious(Position p) {
		p.m_pPosition = p.m_pPosition->m_pPrev;
		return p;
	}
	Position GetLast()const {
		assert(!Empty());
		return Position{ m_pTail };
	}
	bool HasNext(Position p)const {
		return p.m_pPosition != nullptr;
	}
	bool HasPrevious(Position p)const {
		return p.m_pPosition!= nullptr;
	}
	const_reference GetAt(Position p)const {
		return p.m_pPosition->m_Data;
	}
private:
	void Copy(const DoubleList<T> &other) {
		auto other_head = other.m_pHead;
		while (other_head != nullptr) {
			AddBack(other_head->m_Data);
			other_head = other_head->m_pNext;
		}
		m_Size = other.m_Size;
	}
	Node * m_pHead{};
	Node * m_pTail{};
	size_type m_Size{};
};
