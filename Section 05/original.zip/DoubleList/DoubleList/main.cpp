#include "double_list.h"
#include <iostream>
int main() {
	DoubleList<int> list;
	for (int i = 5; i < 10; ++i) {
		list.AddBack(i);
	}
	for (int i = 4; i >= 0; --i) {
		list.AddFront(i);
	}
	//list.Clear();
	//list.AddBack(100);
	auto insPos = list.GetFirst();
	insPos = list.GetNext(insPos);
	//insPos = list.GetPrevious(insPos) ;
	//list.Insert(insPos, 100);

	list.Erase(insPos);
	auto position = list.GetFirst();
	while (list.HasNext(position)) {
		std::cout << list.GetAt(position) << ' ';
		position = list.GetNext(position);
	}
}