#include <iostream>
#include "single_list.h"

int main() {
	SingleList<int> values;
	for (int i = 0; i < 10; ++i) {
		values.Add(i);
	}
	//auto pHead = values.GetHead();
	//auto delNode = pHead->m_pNext;
	//pHead->m_pNext = pHead->m_pNext->m_pNext;

	//std::cout << "Size:" << values.GetSize() << std::endl;
	////values.EraseAfter(pHead);
	////values.InsertAfter(pHead, 100);
	//pHead = values.GetHead();
	//while (pHead != nullptr) {
	//	std::cout << pHead->m_Data << ' ';
	//	pHead = pHead->m_pNext;
	//}
	//std::cout << std::endl; 

	auto position = values.GetFirst(); 
	while (values.HasNext(position)) { 
		std::cout << values.GetAt(position) << ' ';
		position = values.GetNext(position);
	}
	std::cout << std::endl;

}