#pragma once
#include <initializer_list>
#include <cstddef>
#include <cassert>
namespace OldList {
	template<typename T>
	struct Node {
		T m_Data;
		Node *m_pNext{};
		Node(const T & data) :m_Data{ data } {

		}
	};
	template<typename T>
	class SingleList {
	public:
		using size_type = size_t;
		using value_type = T;
		using pointer = T * ;
		using const_pointer = const T *;
		using reference = T & ;
		using const_reference = const T&;
		SingleList() = default;
		SingleList(size_type count, const_reference value) {
			assert(count != 0);
			Add(value);
			if (count == 1)
				return;
			auto tempNode = m_pHead;
			for (size_type i = 1; i < count; ++i, tempNode = tempNode->m_pNext) {
				tempNode->m_pNext = new Node<value_type>{ value };
			}
			m_Size = count;
		}
		SingleList(std::initializer_list<value_type> values) {
			auto itr = values.begin();
			Add(*itr++);
			auto tempNode = m_pHead;
			while (itr != values.end()) {
				tempNode->m_pNext = new Node<value_type>{ *itr++ };
				tempNode = tempNode->m_pNext;
			}
			m_Size = values.size();
		}
		SingleList(const SingleList &other) {
			if (other.Empty())
				return;
			Copy(other);
		}
		SingleList & operator =(const SingleList &other) {
			if (this != &other) {
				Clear();
				Copy(other);
			}
			return *this;
		}
		SingleList(SingleList &&other) {
			m_Size = other.m_Size;
			m_pHead = other.m_pHead;
			other.m_pHead = nullptr;
			other.m_Size = 0;
		}
		SingleList & operator=(SingleList &&other) {
			if (this != &other) {
				m_Size = other.m_Size;
				m_pHead = other.m_pHead;
				other.m_pHead = nullptr;
				other.m_Size = 0;
			}
			return *this;
		}
		~SingleList() {
			Clear();
		}
		const_reference Front()const {
			return m_pHead->m_Data;
		}
		bool Empty()const {
			return m_Size == 0;
		}
		void Clear() {
			if (m_Size == 0)
				return;
			auto pTemp = m_pHead;
			do {
				m_pHead = m_pHead->m_pNext;
				delete pTemp;
				pTemp = m_pHead;
			} while (pTemp != nullptr);
			m_Size = 0;
		}
		void Add(const_reference elem) {
			if (m_Size == 0) {
				m_pHead = new Node<value_type>{ elem };
			}
			else {
				Node<value_type> *tempNode = new Node<value_type>{ elem };
				tempNode->m_pNext = m_pHead;
				m_pHead = tempNode;
			}
			++m_Size;
		}
		void InsertAfter(Node<value_type> *pPosition, const_reference value) {
			assert(m_Size != 0);
			assert(pPosition != nullptr);
			auto newNode = new Node<value_type>{ value };
			newNode->m_pNext = pPosition->m_pNext;
			pPosition->m_pNext = newNode;
			++m_Size;
		}
		void EraseAfter(Node<value_type> *pPosition) {
			assert(m_Size != 0);
			assert(pPosition != nullptr);
			assert(pPosition->m_pNext != nullptr);
			auto delNode = pPosition->m_pNext;
			pPosition->m_pNext = pPosition->m_pNext->m_pNext;
			delete delNode;
			--m_Size;
		}
		size_type GetSize()const {
			return m_Size;
		}
		Node<value_type> * GetHead()const {
			return m_pHead;
		}
	private:
		void Copy(const SingleList &other) {
			auto other_head = other.m_pHead;
			Add(other_head->m_Data);
			other_head = other_head->m_pNext;
			auto tempNode = m_pHead;
			while (other_head != nullptr) {
				tempNode->m_pNext = new Node<value_type>{ other_head->m_Data };
				tempNode = tempNode->m_pNext;
				other_head = other_head->m_pNext;
			}
			m_Size = other.m_Size;
		}
		Node<value_type> *m_pHead{};
		size_type m_Size{};
	};
}
template<typename T>
class SingleList {
private:
	struct Node {
		T m_Data;
		Node *m_pNext{};
		Node(const T & data) :m_Data{ data } {

		}
	};
public:
	class Position {
		Node *m_pPosition;
		Position(Node *p) :m_pPosition{ p } {

		}
		friend class SingleList<T>;
	};
	using size_type = size_t;
	using value_type = T;
	using pointer = T * ;
	using const_pointer = const T *;
	using reference = T & ;
	using const_reference = const T&;
	SingleList() = default;
	SingleList(size_type count, const_reference value) {
		assert(count != 0);
		Add(value);
		if (count == 1)
			return;
		auto tempNode = m_pHead;
		for (size_type i = 1; i < count; ++i, tempNode = tempNode->m_pNext) {
			tempNode->m_pNext = new Node{ value };
		}
		m_Size = count;
	}
	SingleList(std::initializer_list<value_type> values) {
		auto itr = value.begin();
		Add(*itr++);
		auto tempNode = m_pHead;
		while (itr != values.end()) {
			tempNode->m_pNext = new Node{ *itr++ };
			tempNode = temp->m_pNext;
		}
		m_Size = values.size();
	}
	SingleList(const SingleList &other) {
		if (other.Empty())
			return;
		Copy(other);
	}
	SingleList & operator =(const SingleList &other) {
		if (this != &other) {
			Clear();
			Copy(other);
		}
		return *this;
	}
	SingleList(SingleList &&other) {
		m_Size = other.m_Size;
		m_pHead = other.m_pHead;
		other.m_pHead = nullptr;
		other.m_Size = 0;
	}
	SingleList & operator=(SingleList &&other) {
		if (this != &other) {
			m_Size = other.m_Size;
			m_pHead = other.m_pHead;
			other.m_pHead = nullptr;
			other.m_Size = 0;
		}
		return *this;
	}
	~SingleList() {
		Clear();
	}
	const_reference Front()const {
		return m_pHead->m_Data;
	}
	bool Empty()const {
		return m_Size == 0;
	}
	void Clear() {
		if (m_Size == 0)
			return;
		auto pTemp = m_pHead;
		do {
			m_pHead = m_pHead->m_pNext;
			delete pTemp;
			pTemp = m_pHead;
		} while (pTemp != nullptr);
		m_Size = 0;
	}
	void Add(const_reference elem) {
		if (m_Size == 0) {
			m_pHead = new Node{ elem };
		}
		else {
			Node*tempNode = new Node{ elem };
			tempNode->m_pNext = m_pHead;
			m_pHead = tempNode;
		}
		++m_Size;
	}
	void InsertAfter(Position pPosition, const_reference value) {
		assert(m_Size != 0);
		assert(pPosition != nullptr);
		auto newNode = new Node{ value };
		newNode->m_pNext = pPosition.m_pPosition->m_pNext;
		pPosition.m_pPosition->m_pNext = newNode;
		++m_Size;
	}
	void EraseAfter(Position pPosition) {
		assert(m_Size != 0);
		assert(pPosition != nullptr);
		auto delNode = pPosition.m_pPosition->m_pNext;
		pPosition.m_pPosition->m_pNext = pPosition.m_pPosition->m_pNext->m_pNext;
		delete delNode;
		--m_Size;
	}
	size_type GetSize()const {
		return m_Size;
	}

	Position GetFirst()const {
		return Position{ m_pHead };
	}
	Position GetNext(Position p)const {
		p.m_pPosition = p.m_pPosition->m_pNext;
		return p;
	}
	bool HasNext(Position p)const {
		return p.m_pPosition != nullptr;
	}
	const_reference GetAt(Position p)const {
		return p.m_pPosition->m_Data;
	}

private:
	void Copy(const SingleList &other) {
		auto other_head = other.m_pHead;
		Add(other_head->m_Data);
		other_head = other_head->m_pNext;
		auto tempNode = m_pHead;
		while (other_head != nullptr) {
			tempNode->m_pNext = new Node{ other_head->m_Data };
			tempNode = tempNode->m_pNext;
			other_head = other_head->m_pNext;
		}
		m_Size = other.m_Size;
	}
	Node *m_pHead{};
	size_type m_Size{};
};
