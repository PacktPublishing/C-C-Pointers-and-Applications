#include <iostream>
/*
 * The _DOTRACE macro has to be defined HERE
 * in order to enable tracing. Defining it
 * elsewhere won't work
 */
#define _DOTRACE

class Noisy {
	int m_ID = 0;
	static long m_create, m_param, m_assign, m_copyctor, m_dtor, m_movector, m_moveassign;
public:
	Noisy() {
		++m_create;
		//	std::cout << "d[" << id << "]";
	}
	Noisy(int id) :
			m_ID(id) {
		++m_param;
		//	std::cout << "d[" << id << "]";
	}
	Noisy(const Noisy & obj) {
		m_ID = obj.m_ID;
		++m_copyctor;
	}
	Noisy(Noisy && obj)noexcept {
		m_ID = obj.m_ID;
		obj.m_ID = 0 ;
		++m_movector;
	}
	Noisy & operator =(Noisy&&obj)noexcept {
		m_ID = obj.m_ID;
		++m_moveassign;
		return *this;
	}
	Noisy & operator =(const Noisy &obj) {
		m_ID = obj.m_ID;
		++m_assign;
		return *this;
	}
	~Noisy() {
		++m_dtor;
	}
	int GetID() const {
		return m_ID;
	}
	void SetID(int id) {
		m_ID = id;
	}
	friend bool operator <(const Noisy &lv, const Noisy &rv) {
		return lv.m_ID < rv.m_ID;
	}
	friend bool operator >(const Noisy &lv, const Noisy &rv) {
		return lv.m_ID > rv.m_ID;
	}
	friend bool operator ==(const Noisy &lv, const Noisy &rv) {
		return lv.m_ID == rv.m_ID;
	}
	friend class Reporter;
	friend std::ostream & operator <<(std::ostream & out, const Noisy &n) {
		out << n.m_ID;
		return out;
	}
};


class Reporter {
	static Reporter m_reporter;
	Reporter() =default ;
public:
	~Reporter();
};

