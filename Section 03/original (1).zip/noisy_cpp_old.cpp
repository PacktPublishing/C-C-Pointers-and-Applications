#include "noisy_cpp_old.h"
//Static initialization
long Noisy::m_assign = 0;
long Noisy::m_copyctor = 0;
long Noisy::m_create = 0;
long Noisy::m_param = 0;
long Noisy::m_dtor = 0;
long Noisy::m_movector = 0;
long Noisy::m_moveassign = 0;

Reporter Reporter::m_reporter;
Reporter::~Reporter() {
	std::cout << __FUNCSIG__ << std::endl;
#ifdef _DOTRACE
	using namespace std;
	cout << "Noisy default ctors : " << Noisy::m_create << endl;
	cout << "Noisy parameterized ctors : " << Noisy::m_param << endl;
	cout << "Noisy copy ctors : " << Noisy::m_copyctor << endl;
	cout << "Noisy move ctors : " << Noisy::m_movector << endl;
	cout << "Noisy copy assignments : " << Noisy::m_assign << endl;
	cout << "Noisy move assignments : " << Noisy::m_moveassign << endl;
	cout << "Noisy dtors : " << Noisy::m_dtor << endl << endl;
	cout << ">>>> TOTAL OBJECTS CREATED :" << Noisy::m_dtor << endl;
	cout << ">>>> TOTAL FUNCTIONS CALLED :" << Noisy::m_assign + Noisy::m_create
		+ Noisy::m_param + Noisy::m_copyctor + Noisy::m_dtor << endl;
#endif
}