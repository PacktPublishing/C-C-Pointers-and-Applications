#include "GArray.h"
#include <iostream>

#define _DOTRACE
#include "e:/Dropbox/Poash/Training Material/C++/Code/noisy.h"

void Print(const Basic::GArray<int> &arr, const char *message) {
	std::cout << message << std::endl; 
	for (int i = 0; i < arr.GetSize(); ++i) {
		std::cout << arr[i] << ' ';
	}
	std::cout << std::endl; 
}

void Print(const Smart::GArray<int> &arr, const char *message) {
	std::cout << message << std::endl;
	for (int i = 0; i < arr.GetSize(); ++i) {
		std::cout << arr[i] << ' ';
	}
	std::cout << std::endl;
}
Basic::GArray<int> Create(){
	Basic::GArray<int> arr{ 1,2,3,4 };
	return arr;
}
int main() {
	try {
		using namespace Smart;
		GArray<int> arr{}; 
		arr.Insert(0, 100);
		arr.Add(1);
		arr.Add(2);
		arr.Add(3);
		arr.Add(4);
		arr.Insert(5, 200);

		Print(arr, "Elements");
		arr.Insert(3, 400);

		Print(arr, "Elements");
		std::cout << arr.Back() << std::endl; 

		//char buff[4];
		//int *p = new(buff)int{ 4 };

		//Noisy *p = new Noisy[5];
		//for (int i = 0; i < 5; ++i) {
		//	p[i] = i;
		//}
		//delete[]p;

		/*
		Noisy *ptr = static_cast<Noisy*>(
			operator new(sizeof(Noisy) * 5));

		for (int i = 0; i < 5; ++i) {
			new (ptr + i)Noisy{ i };
		}

		for (int i = 0; i < 5; ++i) {
			ptr[i].~Noisy();
		}
		operator delete(ptr);*/

		
		
	}
	catch (std::exception &ex) {
		std::cout << "### EXCEPTION ###" << std::endl;
		std::cout << ex.what() << std::endl;
	}

}