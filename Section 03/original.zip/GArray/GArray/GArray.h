#pragma once
#include <initializer_list>
#include <iostream>
#include <cassert>
#include <stdexcept>
#include "utils.h"
namespace Basic {
	template<typename T>
	class GArray {

	public:
		using size_type = size_t;
		using value_type = T;
		using pointer = T * ;
		using const_pointer = const T*;
		using reference = T & ;
		using const_reference = const T&;
		GArray() = default;
		GArray(size_type count, const_reference elem) {
			m_pBuffer = new T[count];
			for (int i = 0; i < count; ++i) {
				m_pBuffer[i] = elem;
			}
			m_Size = count;
		}
		GArray(std::initializer_list<value_type> list) {
			m_pBuffer = new T[list.size()];
			Copy(list.begin(), list.end(), m_pBuffer);
			m_Size = list.size();
		}
		GArray(const GArray<T> &other) {
			std::cout << "GArray copy ctor" << std::endl;
			m_pBuffer = new value_type[other.m_Size];
			Copy(other.m_pBuffer, other.m_pBuffer + other.m_Size, m_pBuffer);
			m_Size = other.m_Size;
		}
		GArray(GArray<T> && other) {
			std::cout << "GArray move ctor" << std::endl;
			m_pBuffer = other.m_pBuffer;
			m_Size = other.m_Size;
			other.m_pBuffer = nullptr;
			other.m_Size = 0;
		}
		GArray<T> & operator =(const GArray<T> &other) {
			std::cout << "GArray copy assignment" << std::endl;
			if (this != &other) {
				delete[] m_pBuffer;
				m_pBuffer = new value_type[other.m_Size];
				Copy(other.m_pBuffer, other.m_pBuffer + other.m_Size, m_pBuffer);
				m_Size = other.m_Size;
			}
			return *this;
		}
		GArray<T> & operator =(GArray<T> && other) {
			std::cout << "GArray move assignment" << std::endl;
			if (this != &other) {
				delete[] m_pBuffer;
				m_pBuffer = other.m_pBuffer;
				m_Size = other.m_Size;
				other.m_pBuffer = nullptr;
				other.m_Size = 0;
			}
			return *this;
		}
		~GArray() {
			delete[] m_pBuffer;
		}
		void Add(const_reference elem) {
			if (Empty()) {
				m_pBuffer = new value_type[1]{ elem };
			}
			else {
				pointer pTemp = new value_type[m_Size + 1];
				Copy(m_pBuffer, m_pBuffer + m_Size, pTemp);
				pTemp[m_Size] = elem;
				delete[] m_pBuffer;
				m_pBuffer = pTemp;
			}
			++m_Size;
		}
		void Insert(size_type index, const_reference elem) {
			if (index > m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			if ((Empty() && index == 0) || index == m_Size) {
				Add(elem);
				return;
			}
			pointer pTemp = new value_type[m_Size + 1];
			Copy(m_pBuffer, m_pBuffer + index, pTemp);
			pTemp[index] = elem;
			Copy(m_pBuffer + index, m_pBuffer + m_Size, pTemp + index + 1);

			delete[] m_pBuffer;
			m_pBuffer = pTemp;
			++m_Size;
		}
		void Erase(size_type index) {
			if (Empty() || index >= m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			//1,2,3,4,5
			//1,3,4,5
			size_type i = index;
			if (index != (m_Size - 1)) {
				do {
					m_pBuffer[i] = m_pBuffer[i + 1];
					++i;
				} while (i < (m_Size - 1));
			}
			--m_Size;
		}
		const_reference Back()const {
			assert(!Empty());
			return m_pBuffer[m_Size];
		}
		const_reference Front()const {
			assert(!Empty());
			return m_pBuffer[0];
		}
		const_reference operator[](size_type index)const {
			assert(!Empty());
			return m_pBuffer[index];
		}
		reference operator[](size_type index) {
			assert(!Empty());
			return m_pBuffer[index];
		}
		const_reference GetAt(size_type index)const {
			if (index > m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			return m_pBuffer[index];

		}
		reference GetAt(size_type index) {
			if (index > m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			return m_pBuffer[index];
		}
		bool Empty()const {
			return m_Size == 0;
		}
		size_type GetSize()const {
			return m_Size;
		}
		void Clear() {
			delete[]m_pBuffer;
		}
		size_type Find(const_reference elem) {
			for (int i = 0; i < m_Size; ++i) {
				if (m_pBuffer[i] == elem)
					return i;
			}
			return -1;
		}
		pointer GetRawPointer() {
			assert(!Empty());
			return m_pBuffer;
		}
		const_pointer GetRawPointer()const {
			assert(!Empty());
			return m_pBuffer;
		}

	private:
		pointer m_pBuffer{};
		size_type m_Size{};
	};
}
namespace Smart {
	template<typename T>
	class GArray {
	private:

	public:
		using size_type = size_t;
		using value_type = T;
		using pointer = T * ;
		using const_pointer = const T*;
		using reference = T & ;
		using const_reference = const T&;
		GArray() = default;
		GArray(size_type count, const_reference elem) {
			m_pBuffer = Alloc(count);
			for (size_type i = 0; i < count; ++i) {
				new(m_pBuffer + i)value_type{ elem };
			}
			m_Size = count;
			m_Capacity = m_Size;
		}
		GArray(std::initializer_list<value_type> list) {
			m_pBuffer = Alloc(count);
			auto itr = list.begin();
			for (size_type i = 0; i < count; ++i, ++itr) {
				new(m_pBuffer + i)value_type{ *itr };
			}
			m_Size = count;
			m_Capacity = m_Size;
		}
		GArray(const GArray<T> &other) {
			m_pBuffer = Alloc(other.m_Size);
			for (size_type i = 0; i < count; ++i) {
				new(m_pBuffer + i)value_type{ other.m_pBuffer[i] };
			}
			m_Size = other.m_Size;
			m_Capacity = m_Size;
		}
		GArray(GArray<T> && other) {
			m_pBuffer = other.m_pBuffer;
			other.m_pBuffer = nullptr;
			m_Size = other.m_Size;
			m_Capacity = other.m_Capacity;
			other.m_Size = other.m_Capacity = 0;
		}
		GArray<T> & operator =(const GArray<T> &other) {
			std::cout << "GArray copy assignment" << std::endl;
			if (this != &other) {
				Delete();
				m_pBuffer = Alloc(other.m_Size);
				for (size_type i = 0; i < count; ++i) {
					new(m_pBuffer + i)value_type{ other.m_pBuffer[i] };
				}
				m_Size = other.m_Size;
				m_Capacity = m_Size;
			}
			return *this;
		}
		GArray<T> & operator =(GArray<T> && other) {
			std::cout << "GArray move assignment" << std::endl;
			if (this != &other) {
				Delete();
				m_pBuffer = other.m_pBuffer;
				other.m_pBuffer = nullptr;
				m_Size = other.m_Size;
				m_Capacity = other.m_Capacity;
				other.m_Size = other.m_Capacity = 0;
			}
			return *this;
		}
		~GArray() {
			Delete();
		}
		void Add(const_reference elem) {
			if (Empty()) {
				if (m_Capacity == 0) {
					m_pBuffer = Alloc(1);
					++m_Capacity;
				}
				new(m_pBuffer)value_type{ elem };
				++m_Size;
				return;
			}
			else if (m_Size >= m_Capacity) {
				Reserve(m_Size * 2);
			}
			new(m_pBuffer + m_Size)value_type{ elem };
			++m_Size;
		}
		void Reserve(size_type newSize) {
			if (newSize <= m_Capacity)
				return;
			pointer pTemp = Alloc(newSize);
			for (size_type i = 0; i < m_Size; ++i) {
				new (pTemp + i)value_type{ std::move(m_pBuffer[i]) };
			}
			Delete();
			m_pBuffer = pTemp;
			m_Capacity = newSize;
		}
		void Insert(size_type index, const_reference elem) {
			if (index > m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			if (Empty() || index == m_Size) {
				Add(elem);
				return;
			}
			if (m_Size < m_Capacity) {
				size_type i{ m_Size };
				//new(m_pBuffer + i)value_type{ m_pBuffer[i] };
				for (; i > index; --i) {
					m_pBuffer[i] = m_pBuffer[i-1];
				}
				m_pBuffer[i] = elem;
			}
			else {
				int newCapacity = m_Capacity * 2;
				pointer pTemp = Alloc(newCapacity);

				size_type i{};
				for (; i < index; ++i) {
					new(pTemp + i)value_type{ m_pBuffer[i] };
				}
				new(pTemp + i)value_type{ elem };
				++i;
				for (; i <= m_Size; ++i) {
					new(pTemp + i)value_type{ m_pBuffer[i - 1] };
				}
				Delete();
				m_pBuffer = pTemp;
				m_Capacity = newCapacity;


			}
			++m_Size;
		}
		/*
		1 2 3 - - -
		  ^
		1 2 2 3 - -
		1 0 2 3 - -

		1 2 3
		  ^
		1 0 2 3 - -

		*/
		void Erase(size_type index) {
			if (Empty() || index >= m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			//1,2,3,4,5
			//1,3,4,5
			size_type i = index;
			if (index != (m_Size - 1)) {
				do {
					m_pBuffer[i] = m_pBuffer[i + 1];
					++i;
				} while (i < (m_Size - 1));
			}
			--m_Size;
		}
		const_reference Back()const {
			assert(!Empty());
			return m_pBuffer[m_Size-1];
		}
		const_reference Front()const {
			assert(!Empty());
			return m_pBuffer[0];
		}
		const_reference operator[](size_type index)const {
			assert(!Empty());
			return m_pBuffer[index];
		}
		reference operator[](size_type index) {
			assert(!Empty());
			return m_pBuffer[index];
		}
		const_reference GetAt(size_type index)const {
			if (index > m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			return m_pBuffer[index];

		}
		reference GetAt(size_type index) {
			if (index > m_Size) {
				throw std::runtime_error{ "Bad index" };
			}
			return m_pBuffer[index];
		}
		bool Empty()const {
			return m_Size == 0;
		}
		size_type GetSize()const {
			return m_Size;
		}
		size_type GetCapacity()const {
			return m_Capacity;
		}
		void Clear() {
			for (int i = 0; i < m_Size; ++i) {
				m_pBuffer[i].~value_type();
			}
			m_Size = 0;
		}
		size_type Find(const_reference elem) {
			for (int i = 0; i < m_Size; ++i) {
				if (m_pBuffer[i] == elem)
					return i;
			}
			return -1;
		}
		pointer GetRawPointer() {
			assert(!Empty());
			return m_pBuffer;
		}
		const_pointer GetRawPointer()const {
			assert(!Empty());
			return m_pBuffer;
		}

	private:
		pointer m_pBuffer{};
		size_type m_Size{};
		size_type m_Capacity{};
		pointer Alloc(size_type count) {
			auto *p = static_cast<pointer>(operator new(sizeof(value_type) * count));
			assert(p != nullptr);
			return p;
		}
		void Delete() {
			for (int i = 0; i < m_Size; ++i) {
				m_pBuffer[i].~value_type();
			}
			operator delete(m_pBuffer);
		}
	};
}