#include <iostream>
struct Integer {
	int *m_Val{};
public:
	Integer() {
		std::cout << __FUNCSIG__ << std::endl; 
		//__func__, __PRETTY_FUNCTION__
	}
	Integer(int val) :m_Val{ new int{val} } {
		std::cout << __FUNCSIG__ << std::endl;

	}
	Integer(const Integer &other) :m_Val{ new int{*other.m_Val} } {
		std::cout << __FUNCSIG__ << std::endl;

	}
	Integer(Integer &&other)  {
		m_Val = other.m_Val;
		other.m_Val = nullptr;
		std::cout << __FUNCSIG__ << std::endl;

	}
	~Integer() {
		std::cout << __FUNCSIG__ << std::endl;
		delete m_Val;
	}
};
Integer Square(Integer x) {
	Integer temp{ *x.m_Val * *x.m_Val };
	return temp;//Return value optimization
}

void Show(Integer &x) {
	std::cout << "\tShow(Integer &)" << std::endl; 
}

void Show(const Integer &x) {
	std::cout << "\tShow(const Integer &)" << std::endl;
}

void Show(Integer &&x) {
	std::cout << "\tShow(Integer  &&)" << std::endl; 
}
int main() {
	Integer val{ 3 };

	//Integer val2{ std::move(val) };
	Show(std::move(val));
	
	return 0;
}